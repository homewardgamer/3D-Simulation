package com.oom.group3;

import com.oom.group3.util.Vector;

import java.awt.Color;

public class Point3D {
    Vector point;
    Color color;

    Point3D(Vector point, Color color) {
        this.point = point;
        this.color = color;
    }

    void draw() {
        // draw the point
    }
}
